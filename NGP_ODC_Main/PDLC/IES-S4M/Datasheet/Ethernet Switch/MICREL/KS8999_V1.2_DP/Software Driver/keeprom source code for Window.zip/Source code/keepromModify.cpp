// keepromModify.cpp : Modify dialog box
//

#include "stdafx.h"
#include <stdio.h>
#include "keeprom.h"

#include "MainFrm.h"
#include "keepromDoc.h"
#include "keepromView.h"
#include "keepromModify.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




/////////////////////////////////////////////////////////////////////////////
// CModifyDlg dialog used for App About


CModifyDlg::CModifyDlg() : CDialog(CModifyDlg::IDD)
{
	//{{AFX_DATA_INIT(CModifyDlg)

	int i;
	CkeepromApp	*pApp;
	pApp = (CkeepromApp *)AfxGetApp();


	// TODO: Add extra initialization here
	for (i = 0; i < REGCOUNT; i++)
	{
        m_sRegister[ i ].Format("%02X", pApp->gold_data[ i ] );

//		m_cRegister[ i ].EnableWindow(TRUE);
	}

	//}}AFX_DATA_INIT
}

void CModifyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModifyDlg)
    int i;

	CDialog::DoDataExchange(pDX);

    for ( i = 0; i < REGCOUNT; i++ )
    {
 	    DDX_Control(pDX, IDC_EDIT1 + i, m_cRegister[ i ]);
	    DDX_Text(pDX, IDC_EDIT1 + i, m_sRegister[ i ]);
	    DDV_MaxChars(pDX, m_sRegister[ i ], 2);
    }

	//}}AFX_DATA_MAP
}


BOOL CModifyDlg::OnInitDialog() 
{

	CDialog::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/*
BOOL CModifyDlg::OnSetActive() 
{

	UpdateData(FALSE);

	return CPropertyPage::OnSetActive();
}

*/

// App command to run the dialog
/*
void CkeepromApp::OnModifyDlg()
{
	CModifyDlg modifyDlg;
	modifyDlg.DoModal();
}
*/

void CModifyDlg::OnUpdate() 
{
//	SetModified(TRUE);
}

void CModifyDlg::OnOK() 
{
	
    WORD i, j;
    WORD wStrlen;
   // WORD wTemp;
    BOOL bInvalid = 0;
	CString	csTitle;
    char sErrMsg[50];
//    BYTE bData;
//    WORD wMember;
	
	CkeepromApp	*pApp;
	pApp = (CkeepromApp *)AfxGetApp();

	UpdateData(TRUE);

    //
    // Valide numeric strings 
    //
    for ( i = 0; i < REGCOUNT; i++ )
    {
        sprintf ( sErrMsg, "Invalid value for register %3d.", i );
		csTitle.LoadString(IDS_TITLE);        

        wStrlen = m_sRegister[ i ].GetLength();

	    if ( wStrlen  > 0 && wStrlen < 3)
        {
            for ( j = 0; j < wStrlen; j++ )
            {
                if ( !isxdigit ( m_sRegister[ i ].GetAt( j ) ) )
                {
       	            MessageBox( sErrMsg, csTitle, MB_OK | MB_ICONSTOP );
                    bInvalid = 1;
                    break;
                }

            }     
           
//            m_wRegister [ i ] = atoi ( m_sRegister [ i ] );
            sscanf ( m_sRegister [ i ], "%x", &(pApp->gold_data [ i ] ) );
        }
        else 
        {
            MessageBox( sErrMsg, csTitle, MB_OK | MB_ICONSTOP );
            bInvalid = 1;
        }
    }


    if ( !bInvalid )
    {
		for (i = 0; i < REGCOUNT; i++)
		{
			
//			pApp->WriteData ( PORT1CTL4 + i * PORTCTLREGOFFSET, 
//							   (BYTE)( m_wDefaultVLANID [ i ] & PORTVIDLO ));
		}

        CDialog::OnOK();
    }
}

BEGIN_MESSAGE_MAP(CModifyDlg, CDialog)
	//{{AFX_MSG_MAP(CModifyDlg)
    ON_EN_UPDATE(IDC_EDIT1, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT2, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT3, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT4, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT5, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT6, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT7, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT8, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT9, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT10, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT11, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT12, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT13, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT14, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT15, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT16, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT17, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT18, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT19, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT20, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT21, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT22, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT23, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT24, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT25, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT26, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT27, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT28, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT29, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT30, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT41, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT42, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT43, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT44, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT45, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT46, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT47, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT48, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT49, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT50, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT51, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT52, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT53, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT54, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT55, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT56, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT57, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT58, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT59, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT60, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT61, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT62, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT63, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT64, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT65, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT66, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT67, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT68, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT69, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT70, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT71, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT72, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT73, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT74, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT75, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT76, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT77, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT78, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT79, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT80, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT81, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT82, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT83, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT84, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT85, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT86, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT87, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT88, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT89, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT90, OnUpdate)


    ON_EN_UPDATE(IDC_EDIT91, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT92, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT93, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT94, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT95, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT96, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT97, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT98, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT99, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT100, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT101, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT102, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT103, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT104, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT105, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT106, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT107, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT108, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT109, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT110, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT111, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT112, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT113, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT114, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT115, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT116, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT117, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT118, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT119, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT120, OnUpdate)

    ON_EN_UPDATE(IDC_EDIT121, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT122, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT123, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT124, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT125, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT126, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT127, OnUpdate)
    ON_EN_UPDATE(IDC_EDIT128, OnUpdate)

		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CkeepromApp message handlers

