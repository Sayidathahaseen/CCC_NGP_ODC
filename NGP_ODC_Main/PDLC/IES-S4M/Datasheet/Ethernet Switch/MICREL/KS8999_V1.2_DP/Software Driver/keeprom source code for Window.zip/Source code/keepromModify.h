// keepromModify.h : interface of the CkeepromModfy class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_keepromModify_H__DCCF4E0D_9735_11D2_8E53_006008A82731__INCLUDED_)
#define AFX_keepromModify_H__DCCF4E0D_9735_11D2_8E53_006008A82731__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define REGCOUNT    128

class CModifyDlg : public CDialog
{
public:
	CModifyDlg();

// Dialog Data
	//{{AFX_DATA(CModifyDlg)
	enum { IDD = IDD_MODIFY };

    CEdit   m_cRegister [REGCOUNT];
    CString m_sRegister [REGCOUNT];
    WORD    m_wRegister [REGCOUNT];

	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModifyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CModifyDlg)

	virtual BOOL OnInitDialog();
    virtual void OnUpdate();
    virtual void OnOK();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_keepromVIEW_H__DCCF4E0D_9735_11D2_8E53_006008A82731__INCLUDED_)
