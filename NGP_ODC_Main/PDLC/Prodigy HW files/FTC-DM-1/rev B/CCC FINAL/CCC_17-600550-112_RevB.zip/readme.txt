Compressor Controls Corporation
 Des Moines, Iowa
 4/10/13
 
Steve Chebuhar
 PH: (515) 253-3297
 PH: (515) 451-1475 (Home)
 schebuhar@cccglobal.com


BOARD NAME:  	Prodigy Digital FTA Terminal Board
BOARD NUMBER: 	17-600550-112 REV. B
LAYER COUNT:    4


FILE DESCRIPTIONS:  (??=PHYSICAL LAYER, **=DOCUMENTATION LAYER)

    LAYER?.PHO 			COPPER 
    SS?.PHO       		SILK SCREEN 
    SM?.PHO   			SOLDER MASK 
    PM.PHO   			PASTE MASK
    AS?.PHO     		ASSEMBLY DRAWING
    Drilldrawing.*     		DRILL DRAWING
    NCDRILL.*  	 		DRILL INFORMATION FOR PLATED HOLES
    *.REP           		INDIVIDUAL APERTURE REPORT FILES
    17-600550-112_REVB.ASC  	ASCII NETLIST TEST FILE (PADS 2009 FORMAT)
    17-600550-112_REVB.IPC	IPC-356A netlist
    README.TXT      		THIS FILE
    

LIST OF FILES SUPPLIED

04/10/2013  04:22 AM            57,926 LAYER1.pho
04/10/2013  04:22 AM             1,573 LAYER1.rep
04/10/2013  04:22 AM            40,213 LAYER2.pho
04/10/2013  04:22 AM               752 LAYER2.rep
04/10/2013  04:22 AM           290,781 LAYER3.pho
04/10/2013  04:22 AM               588 LAYER3.rep
04/10/2013  04:22 AM           105,215 LAYER4.pho
04/10/2013  04:22 AM             1,243 LAYER4.rep

04/10/2013  04:22 AM            36,029 PMB.pho
04/10/2013  04:22 AM               648 PMB.rep
04/10/2013  04:22 AM            34,732 PMT.pho
04/10/2013  04:22 AM               778 PMT.rep

04/10/2013  04:22 AM            99,646 SSB.pho
04/10/2013  04:22 AM               472 SSB.rep
04/10/2013  04:22 AM           363,333 SST.pho
04/10/2013  04:22 AM               634 SST.rep

04/10/2013  04:22 AM            41,680 SMB.pho
04/10/2013  04:22 AM             1,025 SMB.rep
04/10/2013  04:22 AM            40,384 SMT.pho
04/10/2013  04:22 AM             1,156 SMT.rep

04/10/2013  04:02 PM           767,049 Drilldrawing.pho
04/10/2013  04:02 PM               431 Drilldrawing.rep
04/10/2013  04:22 AM             3,130 NCDRILL.drl
04/10/2013  04:22 AM             5,018 NCDRILL.lst
04/10/2013  04:22 AM               465 NCDRILL.rep

04/10/2013  04:22 AM            84,746 ASB.pho
04/10/2013  04:22 AM               391 ASB.rep
04/10/2013  04:22 AM            58,450 AST.pho
04/10/2013  04:22 AM               432 AST.rep

04/10/2013  01:38 PM         2,078,462 17-600550-112_REVB.asc
04/10/2013  04:22 AM            48,700 17-600550-112_REVB.ipc
04/10/2013  04:04 PM             2,878 readme.txt

              32 File(s)      4,168,960 bytes


