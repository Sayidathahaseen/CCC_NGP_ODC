Compressor Controls Corporation
 Des Moines, Iowa
 4/10/13
 
Steve Chebuhar
 PH: (515) 253-3297
 PH: (515) 451-1475 (Home)
 schebuhar@cccglobal.com


BOARD NAME:  	Prodigy Digital FTA Backplane
BOARD NUMBER: 	17-600550-111 REV. B
LAYER COUNT:    8


FILE DESCRIPTIONS:  (??=PHYSICAL LAYER, **=DOCUMENTATION LAYER)

    layer?.PHO 			COPPER 
    ss?.PHO       		SILK SCREEN 
    sm?.PHO   			SOLDER MASK 
    pm?.PHO   			PASTE MASK
    as?.PHO     		ASSEMBLY DRAWING
    drilldrawing.*     		DRILL DRAWING
    ncdrill.*  	 		DRILL INFORMATION FOR PLATED HOLES
    *.REP           		INDIVIDUAL APERTURE REPORT FILES
    17-600550-111_REVB.ASC  	ASCII NETLIST TEST FILE (PADS 2009 FORMAT)
    17-600550-111_REVB.IPC	IPC-356A netlist
    README.TXT      		THIS FILE
    

LIST OF FILES SUPPLIED

04/10/2013  04:22 AM           111,789 layer1.pho
04/10/2013  04:22 AM             1,194 layer1.rep
04/10/2013  04:22 AM           371,476 layer2.pho
04/10/2013  04:22 AM               490 layer2.rep
04/10/2013  04:22 AM            58,178 layer3.pho
04/10/2013  04:22 AM               737 layer3.rep
04/10/2013  04:22 AM            58,079 layer4.pho
04/10/2013  04:22 AM               737 layer4.rep
04/10/2013  04:22 AM           367,346 layer5.pho
04/10/2013  04:22 AM               490 layer5.rep
04/10/2013  04:22 AM            58,393 layer6.pho
04/10/2013  04:22 AM               737 layer6.rep
04/10/2013  04:22 AM           209,516 layer7.pho
04/10/2013  04:22 AM               449 layer7.rep
04/10/2013  04:22 AM            81,229 layer8.pho
04/10/2013  04:22 AM               861 layer8.rep

04/10/2013  04:22 AM            46,347 pmt.pho
04/10/2013  04:22 AM               694 pmt.rep

04/10/2013  04:22 AM            71,907 ssb.pho
04/10/2013  04:22 AM               526 ssb.rep
04/10/2013  04:22 AM           337,515 sst.pho
04/10/2013  04:22 AM               529 sst.rep

04/10/2013  04:22 AM            52,989 smb.pho
04/10/2013  04:22 AM               619 smb.rep
04/10/2013  04:22 AM            57,386 smt.pho
04/10/2013  04:22 AM             1,103 smt.rep

04/10/2013  03:23 PM           907,549 drilldrawing.pho
04/10/2013  03:23 PM               392 drilldrawing.rep
04/10/2013  04:22 AM             8,450 ncdrill.drl
04/10/2013  04:22 AM            12,431 ncdrill.lst
04/10/2013  04:22 AM               465 ncdrill.rep

04/10/2013  04:22 AM            47,180 asb.pho
04/10/2013  04:22 AM               363 asb.rep
04/10/2013  04:22 AM            88,425 ast.pho
04/10/2013  04:22 AM               403 ast.rep

04/10/2013  03:25 PM         1,510,854 17-600550-111_REVB.asc
04/10/2013  04:22 AM            70,594 17-600550-111_REVB.ipc
04/10/2013  03:32 PM             2,862 readme.txt

	 38 File(s)      4,541,284 bytes


