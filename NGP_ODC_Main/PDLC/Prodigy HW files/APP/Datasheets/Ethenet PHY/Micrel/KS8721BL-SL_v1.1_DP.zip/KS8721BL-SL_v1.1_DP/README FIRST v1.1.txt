===========================================================================

	KSZ8721BL/SL  -  3.3V 10/100BASE-T/TX/FX Physical Layer Transceiver


===========================================================================

Design Package 
Revision History
----------------
	v1.0  :  Initial release
	V1.1  :  Removed Datasheet from Design Package
		 Added IBIS model with ibischk4 parser support
		 Added AN-133 Interfacing Fast Ethernet Transceivers
			to MAC Processors


===========================================================================

Please contact your local Micrel FAE or Salesperson for any question.
