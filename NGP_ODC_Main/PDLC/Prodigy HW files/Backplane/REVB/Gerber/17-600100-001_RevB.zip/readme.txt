Compressor Controls Corporation
 Des Moines, Iowa
 4/12/13
 
Steve Chebuhar
 PH: (515) 253-3297
 PH: (515) 451-1475 (Home)
 schebuhar@cccglobal.com


BOARD NAME:  	Prodigy Backplane
BOARD NUMBER: 	17-600100-001 REV. B
LAYER COUNT:    10


FILE DESCRIPTIONS:  (??=PHYSICAL LAYER, **=DOCUMENTATION LAYER)

    Layer?.PHO 			COPPER 
    SS?.PHO       		SILK SCREEN 
    SM?.PHO   			SOLDER MASK 
    PM?.PHO   			PASTE MASK
    AS?.PHO     		ASSEMBLY DRAWING
    FABDRAWING.*     		DRILL DRAWING
    ncdrill.*  	 		DRILL INFORMATION FOR PLATED HOLES
    *.REP           		INDIVIDUAL APERTURE REPORT FILES
    17-600100-001_revB.ASC  	ASCII NETLIST TEST FILE (PADS 2009 FORMAT)
    17-600100-001_revB.IPC	IPC-356A netlist
    17-600100-001_STACKUP.pdf	LAYER STACKUP
    README.TXT      		THIS FILE
    

LIST OF FILES SUPPLIED

04/09/2013  03:44 PM         5,398,009 Layer1.pho
04/09/2013  03:44 PM             1,381 Layer1.rep
04/09/2013  03:45 PM         3,382,678 Layer10.pho
04/09/2013  03:45 PM               999 Layer10.rep
04/09/2013  03:44 PM         1,950,344 Layer2.pho
04/09/2013  03:44 PM             1,113 Layer2.rep
04/09/2013  03:44 PM         5,735,093 Layer3.pho
04/09/2013  03:44 PM               633 Layer3.rep
04/09/2013  03:44 PM         2,609,387 Layer4.pho
04/09/2013  03:44 PM             1,074 Layer4.rep
04/09/2013  03:44 PM         4,335,393 Layer5.pho
04/09/2013  03:44 PM               997 Layer5.rep
04/09/2013  03:45 PM         5,734,626 Layer6.pho
04/09/2013  03:44 PM               633 Layer6.rep
04/09/2013  03:45 PM         1,245,756 Layer7.pho
04/09/2013  03:45 PM             1,113 Layer7.rep
04/09/2013  03:45 PM         5,558,640 Layer8.pho
04/09/2013  03:45 PM               633 Layer8.rep
04/09/2013  03:45 PM         3,062,043 Layer9.pho
04/09/2013  03:45 PM             1,113 Layer9.rep

04/09/2013  03:45 PM            44,097 PMTOP.pho
04/09/2013  03:45 PM               575 PMTOP.rep

04/12/2013  09:06 AM         1,012,711 SST.pho
04/12/2013  09:06 AM               548 SST.rep

04/09/2013  03:45 PM           131,791 SMBOTTOM.pho
04/09/2013  03:45 PM               897 SMBOTTOM.rep
04/09/2013  03:45 PM           148,101 SMTOP.pho
04/09/2013  03:45 PM             1,265 SMTOP.rep

04/12/2013  09:05 AM         1,286,096 FABDRAWING.pho
04/12/2013  09:05 AM               391 FABDRAWING.rep
04/09/2013  03:46 PM            87,755 NCDRILL.drl
04/09/2013  03:46 PM           123,836 NCDRILL.lst
04/09/2013  03:46 PM               671 NCDRILL.rep

04/09/2013  03:45 PM           686,143 ASTOP.pho
04/09/2013  03:45 PM               393 ASTOP.rep

04/10/2013  05:46 AM         6,150,105 17-600100-001_revB.asc
04/11/2013  11:12 AM        30,472,340 17-600100-001_revB.ipc
04/10/2013  05:46 AM            10,096 17-600100-001_STACKUP.pdf
04/12/2013  09:30 AM             2,813 readme.txt

	 39 File(s)     79,182,282 bytes


