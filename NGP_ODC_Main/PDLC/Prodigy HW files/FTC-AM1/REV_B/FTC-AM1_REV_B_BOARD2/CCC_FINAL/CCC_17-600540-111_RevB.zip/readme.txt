Compressor Controls Corporation
 Des Moines, Iowa
 4/10/13
 
Steve Chebuhar
 PH: (515) 253-3297
 PH: (515) 451-1475 (Home)
 schebuhar@cccglobal.com


BOARD NAME:  	Prodigy Analog FTA Backplane
BOARD NUMBER: 	17-600540-111 REV. B
LAYER COUNT:    6


FILE DESCRIPTIONS:  (??=PHYSICAL LAYER, **=DOCUMENTATION LAYER)

    Layer?.PHO 			COPPER 
    ss?.PHO       		SILK SCREEN 
    sm?.PHO   			SOLDER MASK 
    pm.PHO   			PASTE MASK
    as?.PHO     		ASSEMBLY DRAWING
    fabdrawing.*     		DRILL DRAWING
    ncdrill.*  	 		DRILL INFORMATION FOR PLATED HOLES
    *.REP           		INDIVIDUAL APERTURE REPORT FILES
    FTC-AM1_REV_B_BOARD2.ASC  	ASCII NETLIST TEST FILE (PADS 2009 FORMAT)
    FTC-AM1_REV_B_BOARD2.IPC	IPC-356A netlist
    README.TXT      		THIS FILE
    

LIST OF FILES SUPPLIED

04/10/2013  03:21 PM            43,124 Layer1.pho
04/10/2013  03:21 PM             1,152 Layer1.rep
04/10/2013  03:21 PM           188,043 Layer2.pho
04/10/2013  03:21 PM               738 Layer2.rep
04/10/2013  03:22 PM            38,281 Layer3.pho
04/10/2013  03:22 PM               738 Layer3.rep
04/10/2013  03:22 PM            38,528 Layer4.pho
04/10/2013  03:22 PM               738 Layer4.rep
04/10/2013  03:22 PM           197,871 Layer5.pho
04/10/2013  03:22 PM               738 Layer5.rep
04/10/2013  03:22 PM            55,755 Layer6.pho
04/10/2013  03:22 PM               943 Layer6.rep

04/10/2013  03:22 PM            28,718 pmtop.pho
04/10/2013  03:22 PM               490 pmtop.rep

04/10/2013  03:22 PM           318,752 ssbottom.pho
04/10/2013  03:22 PM               487 ssbottom.rep
04/10/2013  03:22 PM            45,535 sstop.pho
04/10/2013  03:22 PM               403 sstop.rep

04/10/2013  03:22 PM            38,866 smbottom.pho
04/10/2013  03:22 PM               747 smbottom.rep
04/10/2013  03:22 PM            38,854 smtop.pho
04/10/2013  03:22 PM               925 smtop.rep

04/10/2013  04:11 PM           837,810 fabdrawing.pho
04/10/2013  04:11 PM               470 fabdrawing.rep
04/10/2013  03:22 PM             6,502 ncdrill.drl
04/10/2013  03:22 PM             9,419 ncdrill.lst
04/10/2013  03:22 PM               466 ncdrill.rep

04/10/2013  03:22 PM            29,707 asbottom.pho
04/10/2013  03:22 PM               323 asbottom.rep
04/10/2013  03:22 PM            48,030 astop.pho
04/10/2013  03:22 PM               404 astop.rep

04/10/2013  05:40 AM         1,925,441 FTC-AM1_REV_B_BOARD2.asc
04/10/2013  03:22 PM            41,484 FTC-AM1_REV_B_BOARD2.ipc
04/10/2013  04:31 PM             2,862 readme.txt

	 34 File(s)      3,943,344 bytes


