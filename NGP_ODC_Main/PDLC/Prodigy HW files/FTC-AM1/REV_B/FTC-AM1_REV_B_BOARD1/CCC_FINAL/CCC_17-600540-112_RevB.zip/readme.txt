Compressor Controls Corporation
 Des Moines, Iowa
 4/10/13
 
Steve Chebuhar
 PH: (515) 253-3297
 PH: (515) 451-1475 (Home)
 schebuhar@cccglobal.com


BOARD NAME:  	Prodigy Analog FTA Terminal Board
BOARD NUMBER: 	17-600540-112 REV. B
LAYER COUNT:    4


FILE DESCRIPTIONS:  (??=PHYSICAL LAYER, **=DOCUMENTATION LAYER)

    Layer?.PHO 			COPPER 
    ss?.PHO       		SILK SCREEN 
    sm?.PHO   			SOLDER MASK 
    pm?.PHO   			PASTE MASK
    as?.PHO     		ASSEMBLY DRAWING
    fabdrawing.*     		DRILL DRAWING
    ncdrill.*  	 		DRILL INFORMATION FOR PLATED HOLES
    *.REP           		INDIVIDUAL APERTURE REPORT FILES
    17-600550-100_REVB.ASC  	ASCII NETLIST TEST FILE (PADS 2009 FORMAT)
    17-600550-100_REVB.IPC	IPC-356A netlist
    17-600550-100_STACKUP	LAYER STACKUP INFORMATION
    README.TXT      		THIS FILE
    

LIST OF FILES SUPPLIED

04/10/2013  03:55 PM           156,783 Layer1.pho
04/10/2013  03:55 PM             1,045 Layer1.rep
04/10/2013  03:55 PM            35,428 Layer2.pho
04/10/2013  03:55 PM               877 Layer2.rep
04/10/2013  03:55 PM           137,708 Layer3.pho
04/10/2013  03:55 PM               838 Layer3.rep
04/10/2013  03:55 PM            55,576 Layer4.pho
04/10/2013  03:55 PM             1,170 Layer4.rep

04/10/2013  03:56 PM            30,133 pmbottom.pho
04/10/2013  03:56 PM               447 pmbottom.rep
04/10/2013  03:55 PM            28,216 pmtop.pho
04/10/2013  03:55 PM               402 pmtop.rep

04/10/2013  03:55 PM            61,584 ssbottom.pho
04/10/2013  03:55 PM               392 ssbottom.rep
04/10/2013  03:55 PM           333,917 sstop.pho
04/10/2013  03:55 PM               551 sstop.rep

04/10/2013  03:55 PM            36,166 smbottom.pho
04/10/2013  03:55 PM               936 smbottom.rep
04/10/2013  03:55 PM            34,268 smtop.pho
04/10/2013  03:55 PM               892 smtop.rep

04/10/2013  04:20 PM           708,105 fabdrawing.pho
04/10/2013  04:20 PM               470 fabdrawing.rep
04/10/2013  03:56 PM             3,032 ncdrill.drl
04/10/2013  03:56 PM             4,758 ncdrill.lst
04/10/2013  03:56 PM               465 ncdrill.rep

04/10/2013  03:56 PM            68,705 asbottom.pho
04/10/2013  03:56 PM               355 asbottom.rep
04/10/2013  03:56 PM            48,851 astop.pho
04/10/2013  03:56 PM               394 astop.rep

04/10/2013  05:39 AM         3,029,294 FTC-AM1_REV_B_BOARD1.asc
04/10/2013  03:56 PM            30,250 FTC-AM1_REV_B_BOARD1.ipc
04/10/2013  04:32 PM             2,862 readme.txt

	 32 File(s)      4,814,870 bytes


